# AUTUS FAQ

## What is AUTUS?
Protocol for personal AI sovereignty.

## Different from ChatGPT?
- 100% local vs server
- Learns YOUR style vs generic
- Multiple AI vs single

## Is it free?
Core: Yes forever (MIT)

## Status?
Week 1-3 complete (25% MVP)

GitHub: github.com/autus
