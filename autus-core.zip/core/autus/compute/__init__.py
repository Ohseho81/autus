from .slots import compute_slots, MATRIX, TASKS, SLOTS
