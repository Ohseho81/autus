# Work Event Connector

Events: TASK_COMPLETED, QA_PASS, QA_FAIL, etc.
Usage: WORK_CONNECTOR.read(envelope) -> raw -> extract_features(raw)
