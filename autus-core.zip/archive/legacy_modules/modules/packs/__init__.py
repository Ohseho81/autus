# Auto-register all packs
