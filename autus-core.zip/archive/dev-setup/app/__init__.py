# AUTUS — The Operating System of Reality
# "See the Future. Don't Touch It."

__version__ = "1.0.0"
