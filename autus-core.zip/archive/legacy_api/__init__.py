"""AUTUS API Module"""
